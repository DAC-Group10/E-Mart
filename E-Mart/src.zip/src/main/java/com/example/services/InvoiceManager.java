package com.example.services;
import java.util.List;
import java.util.Optional;

import com.example.entities.Invoice;

public interface InvoiceManager 
{
	List<Invoice> getInvoices();
	
	List<Invoice> getInvoices(int custid);
	
	void addInvoice(Invoice invoice);
	
	Optional<Invoice> getInvoice();
	
}
