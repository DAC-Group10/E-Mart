import React from "react";

export default function ContactUs() {
  return <div>hello contacct me</div>;
}
