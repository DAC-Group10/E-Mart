import { Categories } from "./Categories";
import './Home.css'

export function Home() {
  return (
    <div className="body">
          <Categories />
    </div>
  )
}